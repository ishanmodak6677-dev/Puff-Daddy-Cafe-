# Puff Daddy Cafe — production deployment bundle

This ZIP contains the optimized website files, a small Node.js server, and a GitHub Actions workflow for GitHub Pages.

## Deploy on GitHub Pages

1. Extract the ZIP and add its contents to the **root** of a GitHub repository. Keep the `.github` folder and the `site` folder.
2. Push the files to the repository's `main` branch.
3. In the repository, open **Settings → Pages** and set the source to **GitHub Actions**.
4. The included workflow publishes the prebuilt website. GitHub shows the live URL in the Pages settings and in the workflow run.

The site uses relative paths, includes a GitHub Pages `404.html` fallback for the Menu route, and includes `.nojekyll` for static asset serving. You do not need to build the source again for this bundle.

## Run with Node.js

Node.js 18 or newer is required. From the repository root, run:

```sh
npm start
```

The server listens on port 3000 by default. Set the `PORT` environment variable if your hosting provider assigns a different port. It uses only Node.js built-in modules; no `npm install` is needed.

GitHub Pages serves the static `site` folder; it does not run the Node.js server. Use `npm start` on a Node.js hosting provider if you specifically need a running server process.
